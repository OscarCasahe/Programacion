package Examen;

import java.util.Scanner;

public class ej1 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int num;
        int numCompleto=0;
        int contador=0;

            System.out.println("Introduzca el número uno por uno, introduzca -10 si desea parar la construcción del número.");
        do {
                num = sc.nextInt();
            if (num!=-10 && num>0){

                numCompleto=numCompleto*10+num;
                contador++;
            }else if (num!=-10 && num<0){
                numCompleto=numCompleto*10-num;
                contador++;
            }



            }while(num!=-10 && contador<=5);

        System.out.println("Su número "+numCompleto+" tiene "+contador+" dígitos");




        System.out.println("Su número tiene "+contador+" dígitos");
    }
}
