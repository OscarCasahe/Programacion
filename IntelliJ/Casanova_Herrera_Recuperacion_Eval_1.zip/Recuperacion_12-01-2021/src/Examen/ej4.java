package Examen;

import java.util.Arrays;
import java.util.Scanner;

public class ej4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int [] v=new int[100];



        for (int i = 0; i <v.length ; i++) {
            v[i]=(int)(Math.random()*(100-18)+18);
            String cadena = Integer.toString(v[i]);



        }


    }
    public static int [] marcaPrimos (int [] a){
        boolean primo=true;
        for (int i = 2; i <a.length ; i++) {

            if (a[i]%i==0){
                primo=false;
            }else{
                System.out.print("**");

            }

        }

    }
}
