package Examen;

import java.util.Scanner;

public class ej2 {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
                int altura;

                System.out.println("Introduzca la altura");
                do {

                    altura= sc.nextInt();
                }while (altura<=3);

                for (int i = 0; i <altura ; i++) {


                    if (i%2==0) {
                        if (i == 0) {
                            System.out.print("       ******       ");
                        } else if (i == 2){
                            System.out.println("***********");
                    }else if(i==1){
                            System.out.print("      **    **      ");
                        } else if (i == 4){
                            System.out.println("**************");
                        }else if(i==3){
                            System.out.print("     ****    ****     ");
                        }
                        }else if(i==5){
                        System.out.print("    ******    ******    ");
                        }else if (i == 4){
                        System.out.println("**************");
                    }
                    else if(i==7){
                        System.out.print("   ********    ********   ");
                        }else if(i==9){
                        System.out.print("  **********    **********  ");
                        }
                    }

                    System.out.println("");
                }
           }
}
