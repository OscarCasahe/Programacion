package Examen;

import java.util.Arrays;

public class ej5 {
    public static void main(String[] args) {
        int [][] matriz= new int[4][4];

        for (int i = 0; i < matriz.length ; i++) {
            for (int j = 0; j <matriz[i].length ; j++) {
                matriz[i][j]=(int)(Math.random()*100);
            }

        }
        for (int[] filas : matriz){
            System.out.println(Arrays.toString(filas));
        }

        System.out.println("El resultado de eliminaFilasPares es:");
        System.out.println("");
        System.out.println(Arrays.toString(eliminarFilasPares(matriz)));

    }

    public static int[][] eliminarFilasPares(int[][] matriz){

        int[][] resultado= new int[2][4];

        for (int i = 1; i < matriz.length ; i++) {
            for (int j = 0; j <matriz[i].length ; j++) {
                if (i%2==0){
                   resultado[i][j]=matriz[i][j];
                }
            }

        } return resultado;
    }

    public static int[][] eliminarFilasImpares(int[][] matriz){

        int[][] resultado= new int[2][4];

        for (int i = 0; i < matriz.length ; i++) {
            for (int j = 0; j <matriz[i].length ; j++) {
                if (i%2==0){
                    resultado[i][j]=matriz[i][j];
                }
            }

        } return resultado;
    }


}
