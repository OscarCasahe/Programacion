package Examen;

import java.util.Scanner;

public class ej3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner((System.in));
        String palabra="hola";
        String palabraOculta="----";
        String [] letrasAbc= {"a","b","c","d","e","f","g","h","i","j","k","l","m",
                "n","ñ","o","p","q","r","s","t","u","v","w","x","y","z"};
        int posicion;
        char letra;
        String letraAbc;


        do {
            System.out.println("Introduzca una letra en función de su posición el el abecedario (siendo a=0, b=1...):");
            posicion= sc.nextInt();
            letraAbc = letrasAbc[posicion];
            letra=letraAbc.charAt(0);
            System.out.println(palabraAhorcado(palabra,palabraOculta,letra));


        }while (palabra.equals(palabraOculta));


    }
    public static String palabraAhorcado(String palabra,String palabraOculta, char a){

      String resultado= "";
        String letra = Character.toString(a);

        for (int i = 0; i <palabra.length() ; i++) {
            if (letra.equals(palabraOculta.charAt(i))){
                resultado+=a;
                System.out.println();
            }else{
                resultado+="-";
            }
        }

        return resultado;
    }
}
