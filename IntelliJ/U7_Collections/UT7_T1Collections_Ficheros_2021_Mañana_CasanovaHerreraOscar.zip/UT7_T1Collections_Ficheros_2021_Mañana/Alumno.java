public class Alumno implements Comparable<Alumno>{
    private String nombre;
    private String apellidos;
    private String dni;
    private int id;
    private String unidad;
    private static int generadorId=1;

    public Alumno(String nombre, String apellidos, String dni, String unidad) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.dni = dni;
        this.id = generadorId;
        this.unidad = unidad;

        generadorId++;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public static int getGeneradorId() {
        return generadorId;
    }

    public static void setGeneradorId(int generadorId) {
        Alumno.generadorId = generadorId;
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", dni='" + dni + '\'' +
                ", id=" + id +
                ", unidad='" + unidad + '\'' +
                '}';
    }

    @Override
    public int compareTo(Alumno a) {
        return this.apellidos.compareTo(a.apellidos);
    }
}
