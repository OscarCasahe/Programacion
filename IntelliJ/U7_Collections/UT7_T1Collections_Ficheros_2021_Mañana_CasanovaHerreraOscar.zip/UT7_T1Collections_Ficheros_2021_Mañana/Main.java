import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        Map<String, LinkedList<Alumno>> alumnos;

        Instituto i1 = new Instituto();

        Alumno a1 = new Alumno("Óscar", "Casanova", "111111111X", "Primero");
        Alumno a2 = new Alumno("Marco", "Barrera", "222222222X", "Segundo");
        Alumno a3 = new Alumno("Carmen", "Moreno", "333333333X", "Tercero");
        Alumno a4 = new Alumno("Miriam", "Gómez", "444444444X", "Primero");
        Alumno a5 = new Alumno("Elena", "Hidalgo", "555555555X", "Segundo");
        Alumno a6 = new Alumno("Manuel", "Calado", "666666666X", "Tercero");
        Alumno a7 = new Alumno("Juan", "López", "77777777X", "Primero");
        Alumno a8 = new Alumno("Jose Luís", "Rodríguez", "888888888X", "Segundo");
        Alumno a9 = new Alumno("Inés", "Jurado", "999999999X", "Tercero");
        Alumno a10 = new Alumno("Lucía", "Postigo", "121212121X", "Primero");

        i1.addAlumnoUnidad(a1,"Primero");
        i1.addAlumnoUnidad(a2,"Primero");
        i1.addAlumnoUnidad(a3,"Primero");
        i1.addAlumnoUnidad(a4,"Segundo");
        i1.addAlumnoUnidad(a5,"Segundo");
        i1.addAlumnoUnidad(a6,"Segundo");
        i1.addAlumnoUnidad(a7,"Tercero");
        i1.addAlumnoUnidad(a8,"Tercero");
        i1.addAlumnoUnidad(a9,"Tercero");
        i1.addAlumnoUnidad(a10,"Tercero");


        System.out.println(i1);

        System.out.println();
        System.out.println("Alumnos de Tercero:");

        i1.mostrarAlumnosUnidad("Tercero");

        System.out.println();
        i1.obtenerUnidadAlumno(2);
        System.out.println();

        i1.mostrarTodosAlumnosOrdenados();


        i1.guardarAlumnos();





    }




}
