import java.io.*;
import java.util.*;

public class Instituto implements Serializable {

    Map<String, LinkedList<Alumno>> unidades = new TreeMap<>();


    public void mostrarTodosAlumnosOrdenados(){
        unidades.get(unidades);

        Collection<LinkedList<Alumno>> alumnos =  unidades.values();

        Iterator it = alumnos.iterator();

        while( it.hasNext()){
            LinkedList<Alumno> lista = (LinkedList<Alumno>) it.next();

            for (Alumno a : lista){
                System.out.println(a);
            }
        }
    }

    public void obtenerUnidadAlumno(int id){

        Collection<LinkedList<Alumno>> alumnos = unidades.values();

        Iterator it = alumnos.iterator();

        while (it.hasNext()){

            LinkedList<Alumno> lista = (LinkedList<Alumno>) it.next();

            for (Alumno a : lista){
                if (a.getId() == id){
                    System.out.println(a.getUnidad());
                }
            }
        }
    }


    public LinkedList<Alumno> mostrarAlumnosUnidad(String unidad) {

       unidades.get(unidad).sort(new Comparator<Alumno>() {
           @Override
           public int compare(Alumno o1, Alumno o2) {
               return o1.getDni().compareTo(o2.getDni());
           }
       });
        LinkedList<Alumno> resultado = new LinkedList<>(unidades.get(unidad));

       return resultado;
    }


    public void addAlumnoUnidad(Alumno a, String unidad){

        if (unidades.containsKey(unidad)){
            unidades.get(unidad).add(a);
        }else {
            unidades.put(unidad, new LinkedList<Alumno>());
            unidades.get(unidad).add(a);
        }

    }


    public void cargarAlumnos(){
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("alumnos.dat"));

            while(true){

            }




        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public static void guardarAlumnos(LinkedList<Alumno> alumnos) {
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("alumnos.dat"));

            Iterator it = alumnos.iterator();

            while (it.hasNext()) {
                os.writeObject(it.next());
            }

            os.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}
